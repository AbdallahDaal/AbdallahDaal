#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <unistd.h>

#define TOTAL_CODES   4
#define ALL_COLORS    9
#define NUM_ATTEMPTS  10

void generateSecretCode(char *secretCode) {
    srand(time(NULL));
    int used[ALL_COLORS] = {0};
    for (int i = 0; i < TOTAL_CODES; i++) {
        int color;
        do {
            color = rand() % ALL_COLORS;
        } while (used[color]);
        secretCode[i] = '0' + color;
        used[color] = 1;
    }
    secretCode[TOTAL_CODES] = '\0';
}

void evaluateGuess(char *secretCode, char *guess, int *rightPosition, int *wrongPosition) {
    int frequencySecret[ALL_COLORS] = {0};
    int frequencyGuess[ALL_COLORS] = {0};
    *rightPosition = 0;
    *wrongPosition = 0;

    for (int i = 0; i < TOTAL_CODES; i++) {
        if (guess[i] == secretCode[i]) {
            (*rightPosition)++;
        } else {
            frequencySecret[secretCode[i] - '0']++;
            frequencyGuess[guess[i] - '0']++;
        }
    }

    for (int i = 0; i < ALL_COLORS; i++) {
        *wrongPosition += (frequencySecret[i] < frequencyGuess[i]) ? frequencySecret[i] : frequencyGuess[i];
    }
}

int main(int argc, char *argv[]) {
    char secretCode[TOTAL_CODES + 1];
    int attempts = NUM_ATTEMPTS;

    for (int i = 1; i < argc; i += 2) {
        if (strcmp(argv[i], "-c") == 0) {
            strncpy(secretCode, argv[i + 1], TOTAL_CODES);
            secretCode[TOTAL_CODES] = '\0';
        } else if (strcmp(argv[i], "-t") == 0) {
            attempts = atoi(argv[i + 1]);
        }
    }

    if (secretCode[0] == '\0') {
        generateSecretCode(secretCode);
    }

    printf("Will you find the secret code?\n");
    printf("Please enter a valid guess\n");

    int rightPosition, wrongPosition;
    char guess[TOTAL_CODES + 1];

    for (int attempt = 0; attempt < attempts; attempt++) {
        printf("---\nRound %d\n", attempt);
        printf(">"); fflush(stdout);

        char buffer[TOTAL_CODES + 1];
        int pos = 0;
        char c;

        while (1) {
            int result = read(STDIN_FILENO, &c, 1);
            if (result < 0) {
                perror("read");
                exit(EXIT_FAILURE);
            } else if (result == 0) {
                printf("\n");
                return 0;
            }
            if (c == '\n') {
                break;
            }
            if (pos < TOTAL_CODES && (c >= '0' && c <= '8')) {
                buffer[pos++] = c;
            }
        }

        buffer[pos] = '\0';

        if (strcmp(buffer, "quit") == 0) {
            printf("Exiting the game...\n");
            return 0;
        }

        if (strlen(buffer) != TOTAL_CODES) {
            printf("Wrong input!\n");
            attempt--;
            continue;
        }

        strncpy(guess, buffer, TOTAL_CODES);
        guess[TOTAL_CODES] = '\0';

        evaluateGuess(secretCode, guess, &rightPosition, &wrongPosition);
        if (rightPosition == TOTAL_CODES) {
            printf("Congratz! You did it!\n");
            return 0;
        } else {
            printf("Well placed pieces: %d\n", rightPosition);
            printf("Misplaced pieces: %d\n", wrongPosition);
        }
    }

    printf("Sorry, you have used all attempts. The secret code was: %s\n", secretCode);

    return 0;
}
