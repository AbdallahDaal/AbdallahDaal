# Welcome to My Mastermind
***

## Task
No problem. The challenge was replacing the forbidden functions which increased the difficulty level of the program. Also, creating the EOT was challenging.

## Description
With functions like fgets, scanf being forbidden in the project, Read() and write() had to be implemented for Gandalf to pass.

## Installation
My project does not require any installation.

## Usage
My project is a game called Mastermind composed of 9 pieces of different colors.
A secret code is then composed of 4 distinct pieces. The player has 10 attempts to find the secret code.
After each input, the game indicates to the player the number of well placed pieces and the number of misplaced pieces. Pieces will be '0' '1' '2' '3' '4' '5' '6' '7' '8'. If the player finds the code, he wins, and the game stops. 
A misplaced piece is a piece that is present in the secret code butthat is not in a good position.
```
./my_project argument1 argument2
```

### The Core Team


<span><i>Made at <a href='https://qwasar.io'>Qwasar SV -- Software Engineering School</a></i></span>
<span><img alt='Qwasar SV -- Software Engineering School's Logo' src='https://storage.googleapis.com/qwasar-public/qwasar-logo_50x50.png' width='20px' /></span>
