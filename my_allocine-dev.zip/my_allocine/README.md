# Welcome to My Allocine
***

## Task
To objective is simply to write SQL requests for actor's ID, genres, directors, movies, movie_genres, director's_genres, reviews, movie_rating_reviews' movie_actors.

## Description
By following the provided instructions which is to first download the Database, followed by connecting the database with Sqlite and finally to type in the command line to perform sql queries.

## Installation
My project does not require any installation.

## Usage
By pulling a movie data from a website.
```
./my_allocine
```

### The Core Team


<span><i>Made at <a href='https://qwasar.io'>Qwasar SV -- Software Engineering School</a></i></span>
<span><img alt='Qwasar SV -- Software Engineering School's Logo' src='https://storage.googleapis.com/qwasar-public/qwasar-logo_50x50.png' width='20px' /></span>
