requests = {}


requests['Display all actors'] = <<-SQL
SELECT * FROM actors;
SQL

requests['Display all genres'] = <<-SQL
SELECT * FROM genres;
SQL

requests['Display the name and year of the movies'] = <<-SQL
SELECT mov_title, mov_year FROM movies;
SQL

requests['Display reviewer name from the reviews table'] = <<-SQL
SELECT rev_name FROM reviews;
SQL


requests["Find the year when the movie American Beauty released"] = <<-SQL
SELECT   mov_year FROM movies  WHERE mov_title = 'American Beauty';
SQL

requests["Find the movie which was released in the year 1999"] = <<-SQL
SELECT mov_title FROM movies WHERE mov_year = 1999;
SQL

requests["Find the movie which was released before 1998"] = <<-SQL
SELECT mov_title FROM movies WHERE mov_year < 1998;
SQL



requests["Find the name of all reviewers who have rated 7 or more stars to their rating order by reviews rev_name (it might have duplicated names :-))"] = <<-SQL
SELECT reviews.rev_name FROM reviews JOIN movies_ratings_reviews ON reviews.id = movies_ratings_reviews.rev_id WHERE movies_ratings_reviews.rev_stars >= 7 ORDER BY reviews.rev_name;
SQL

requests["Find the titles of the movies with ID 905, 907, 917"] = <<-SQL
SELECT mov_title FROM movies WHERE id IN (905, 907, 917);
SQL




requests["Find the list of those movies with year and ID which include the words Boogie Nights"] = <<-SQL
SELECT id, mov_title AS name, mov_year AS year  FROM movies WHERE mov_title LIKE '%Boogie Nights%';
SQL



requests["Find the ID number for the actor whose first name is 'Woody' and the last name is 'Allen'"] = <<-SQL
SELECT id FROM actors WHERE act_fname = 'Woody' AND act_lname = 'Allen';
SQL



requests["Find the actors with all information who played a role in the movies 'Annie Hall'"] = <<-SQL
SELECT a.id, a.act_fname, a.act_lname, a.act_gender
FROM actors a
JOIN movies_actors ma ON a.id = ma.act_id
JOIN movies m ON ma.mov_id = m.id
WHERE m.mov_title = 'Annie Hall';
SQL





requests["Find the first and last names of all the actors who were cast in the movies 'Annie Hall', and the roles they played in that production"] = <<-SQL
SELECT actors.act_fname AS first_name, actors.act_lname AS last_name, movies_actors.role 
FROM actors 
JOIN movies_actors ON actors.id = movies_actors.act_id 
JOIN movies ON movies_actors.mov_id = movies.id 
WHERE movies.mov_title = 'Annie Hall';
SQL




requests["Find the name of movie and director who directed a movies that casted a role as Sean Maguire"] = <<-SQL
SELECT d.dir_fname, d.dir_lname, m.mov_title
FROM movies m
JOIN movies_actors ma ON m.id = ma.mov_id
JOIN directors_movies dm ON m.id = dm.mov_id
JOIN directors d ON dm.dir_id = d.id
WHERE ma.role = 'Sean Maguire';

SQL



requests["Find all the actors who have not acted in any movie between 1990 and 2000 (select only actor first name, last name, movie title and release year)"] = <<-SQL
SELECT a.act_fname, a.act_lname, b.mov_title, 
CAST(SUBSTRING (b.mov_dt_rel, 0, 5) AS INT) As release_year FROM actors a, movies b, movies_actors c WHERE (release_year NOT BETWEEn '1990' AND '2000' AND a.id = c.act_id AND b.id = c.mov_id ) and (a.act_fname NOT IN ('Kevin'))

SQL