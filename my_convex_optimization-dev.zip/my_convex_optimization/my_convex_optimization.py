import numpy as np
import matplotlib.pyplot as plt
from scipy.optimize import linprog

# Function for plotting
def plot_function(f, x_values):
    x_range = np.linspace(min(x_values) - 1, max(x_values) + 1, 1000)
    y_values = f(x_range)
    plt.plot(x_range, y_values, label='f(x)')
    plt.scatter(x_values, f(x_values), color='red')
    plt.xlabel('x')
    plt.ylabel('f(x)')
    plt.title('Function Visualization')
    plt.legend()
    plt.grid(True)
    plt.show()

# Bisection method for root-finding
def find_root_bisection(f, lower_bound, upper_bound, epsilon=0.001):
    while (upper_bound - lower_bound) / 2.0 > epsilon:
        midpoint = (lower_bound + upper_bound) / 2.0
        if f(midpoint) == 0:
            return midpoint
        elif f(lower_bound) * f(midpoint) < 0:
            upper_bound = midpoint
        else:
            lower_bound = midpoint
    return (lower_bound + upper_bound) / 2.0

# Newton-Raphson method for root-finding
def find_root_newton_raphson(f, f_prime, initial_point, epsilon=0.001, max_iters=1000):
    x = initial_point
    for _ in range(max_iters):
        fx = f(x)
        if abs(fx) < epsilon:
            return x
        derivative = f_prime(x)
        if derivative == 0:
            raise ValueError("Derivative is zero. Solution cannot be found.")
        x -= fx / derivative
    return x

# Gradient descent for function minimization
def gradient_descent(f, f_prime, start_point, alpha=0.1, epsilon=0.001, max_iters=1000):
    x = start_point
    for _ in range(max_iters):
        gradient = f_prime(x)
        if abs(gradient) < epsilon:
            break
        x -= alpha * gradient
    return x

# Linear programming solver
def solve_linear_problem(A, b, c):
    result = linprog(c, A_ub=A, b_ub=b, method='simplex')
    if result.success:
        return result.fun, result.x
    else:
        raise ValueError("Solution could not be found.")

# Ensure that these functions are accessible for the testing framework
if __name__ == "__main__":
    # Example usage
    pass
import numpy as np
import matplotlib.pyplot as plt
from scipy.optimize import linprog

# Function for plotting
def print_a_function(f, x_values):
    x_range = np.linspace(min(x_values) - 1, max(x_values) + 1, 1000)
    y_values = f(x_range)
    plt.plot(x_range, y_values, label='f(x)')
    plt.scatter(x_values, f(x_values), color='red')
    plt.xlabel('x')
    plt.ylabel('f(x)')
    plt.title('Function Visualization')
    plt.legend()
    plt.grid(True)
    plt.show()

# Bisection method for root-finding
def find_root_bisection(f, lower_bound, upper_bound, epsilon=0.001):
    while (upper_bound - lower_bound) / 2.0 > epsilon:
        midpoint = (lower_bound + upper_bound) / 2.0
        if f(midpoint) == 0:
            return midpoint
        elif f(lower_bound) * f(midpoint) < 0:
            upper_bound = midpoint
        else:
            lower_bound = midpoint
    return (lower_bound + upper_bound) / 2.0

# Newton-Raphson method for root-finding
def find_root_newton_raphson(f, f_prime, initial_point, epsilon=0.001, max_iters=1000):
    x = initial_point
    for _ in range(max_iters):
        fx = f(x)
        if abs(fx) < epsilon:
            return x
        derivative = f_prime(x)
        if derivative == 0:
            raise ValueError("Derivative is zero. Solution cannot be found.")
        x -= fx / derivative
    return x

# Gradient descent for function minimization
def gradient_descent(f, f_prime, start_point, alpha=0.1, epsilon=0.001, max_iters=1000):
    x = start_point
    for _ in range(max_iters):
        gradient = f_prime(x)
        if abs(gradient) < epsilon:
            break
        x -= alpha * gradient
    return x

# Linear programming solver
def solve_linear_problem(A, b, c):
    result = linprog(c, A_ub=A, b_ub=b, method='simplex')
    if result.success:
        return result.fun, result.x
    else:
        raise ValueError("Solution could not be found.")

# Ensure that these functions are accessible for the testing framework
if __name__ == "__main__":
    # Example usage
    pass

