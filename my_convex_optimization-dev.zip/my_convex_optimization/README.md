# Welcome to My Convex Optimization
***

## Task
This project tackles fundamental optimization problems, specifically: finding roots of functions using the bisection and Newton-Raphson methods, minimizing functions using gradient descent, solving linear programming problems with the simplex method, the challenge lies in implementing and testing these algorithms to ensure accuracy and efficiency.
## Description
This code provides implementations for various optimization techniques like root finding, function minimization and linear programming.

## Installation
I did pip install numpy matplotlib scipy

## Usage
Function plotting, root-finding, minimization and finally linear programming. 
```
./my_convex_optimization
```

### The Core Team


<span><i>Made at <a href='https://qwasar.io'>Qwasar SV -- Software Engineering School</a></i></span>
<span><img alt='Qwasar SV -- Software Engineering School's Logo' src='https://storage.googleapis.com/qwasar-public/qwasar-logo_50x50.png' width='20px' /></span>
