# Welcome to My Paypal
***

## Task
The primary challenge is to effectively detect fraudulent credit card transactions from a highly imbalanced dataset, where fraudulent transactions constitute only 0.172% of total transactions. The problem is critical as undetected fraud results in significant financial losses and impacts customer trust. The goal is to build a machine learning model that accurately identifies fraudulent transactions while minimizing false positives.

## Description
I used the Dataset that was provided by FriendPay. My approach includes cleaning and exploring the data, visualizing patterns, and applying machine learning algorithms to build a fraud detection model. I’ll measure its performance with the Area Under the Precision-Recall Curve (AUPRC) due to the dataset's imbalance. The aim is to create a model that helps FriendPay reduce financial losses by effectively identifying fraudulent transactions.

## Installation
pip install seaborn
pip install xgboost
pip install sci-kit learn imbalanced learn

## Usage
This project focuses on improving fraud detection for FriendPay by using machine learning algorithms to identify fraudulent transactions in an imbalanced dataset. Here’s a simple breakdown of how it works:
Data Preparation:

We transformed the 'Amount' feature using a logarithmic function to make its distribution more normal and easier for the models to work with.
To handle the class imbalance (fraudulent transactions make up just 0.172% of the data), we used SMOTE, which generates synthetic data points for the minority class (fraudulent transactions) to balance things out.
Modeling:

We tested several machine learning models, including Logistic Regression, Decision Tree, Gaussian Naive Bayes, Random Forest, and XGBoost.
While all models performed well overall, Random Forest and XGBoost stood out, showing better precision in detecting fraudulent transactions. This is crucial because we need models that can accurately identify fraud without flagging too many legitimate transactions as fraudulent.
Evaluation:

Precision was the key metric used, as it measures how accurately the models predict fraud. Both Random Forest and XGBoost performed the best in this area, making them ideal candidates for real-world deployment in fraud detection.
Next Steps:

While the models are already effective, we recommend further hyperparameter tuning to improve performance.
Once fine-tuned, these models can be integrated into FriendPay’s fraud detection system, helping to reduce fraudulent transactions and improve overall security.
```
./my_project argument1 argument2
```

### The Core Team


<span><i>Made at <a href='https://qwasar.io'>Qwasar SV -- Software Engineering School</a></i></span>
<span><img alt='Qwasar SV -- Software Engineering School's Logo' src='https://storage.googleapis.com/qwasar-public/qwasar-logo_50x50.png' width='20px' /></span>
