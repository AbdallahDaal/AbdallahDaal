# Welcome to Atari Games
***

## Task
The problem is teaching an AI to play Atari games by learning from its own actions, all while dealing with the complexity of visual inputs and the need for real-time decision-making. The challenge lies in training the AI to perform better than humans in a range of Atari games.

## Description
I used Deep Q-Networks (DQN) for this project. DQN helps the AI learn how to maximize its score in each game by interacting with the environment, receiving feedback, and improving its gameplay. I started with simpler games like CartPole and progressed to more complex ones like Space Invaders and Pacman.

## Installation
The user has to install the following libraries for the code to function:
!pip install gym==0.26.1
!pip install -q stable-baselines3[extra]
!pip install -q ale-py
!pip install shimmy>=2.0
!pip install autorom[accept-rom-license]

## Usage
To play the games:
python cartpole.py

```
./my_project argument1 argument2
```

### The Core Team


<span><i>Made at <a href='https://qwasar.io'>Qwasar SV -- Software Engineering School</a></i></span>
<span><img alt='Qwasar SV -- Software Engineering School's Logo' src='https://storage.googleapis.com/qwasar-public/qwasar-logo_50x50.png' width='20px' /></span>
