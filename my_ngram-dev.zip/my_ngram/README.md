# Welcome to My Ngram
***

## Task
The challenge was declaration of the ascii table into my code. I found out that I could use the function "ascii" as an array.

## Description
I declared and called the ascii as an array which made my code shorter and I put to loop through as my_ngram.

## Installation
My project does not require any installation.

## Usage
My project takes 1 or multiple strings as arguments. It displays one per line, each character and the numbers of times it appears. Order will be alphanumerical.
```
./my_project argument1 argument2
```

### The Core Team


<span><i>Made at <a href='https://qwasar.io'>Qwasar SV -- Software Engineering School</a></i></span>
<span><img alt='Qwasar SV -- Software Engineering School's Logo' src='https://storage.googleapis.com/qwasar-public/qwasar-logo_50x50.png' width='20px' /></span>
