#include <stdio.h>
#include <string.h> 
#define MAX_ARRAY_SIZE 128

void fill_array(int* sun, char* moon){
    int index = 0;
    while (moon[index] != '\0'){
        int ascii = ((int) moon[index]);
        sun[ascii]++;
        index++;
    }
}

void print_array(int* sun){
    for (int index = 0; index < MAX_ARRAY_SIZE; index++){
        if (sun[index] > 0){
            printf("%c:%d\n", (char)index, sun[index]); 
        }
    }
}

int main(int ac, char **av){
    int index = 1;
    int array[MAX_ARRAY_SIZE] = {0};
    while (index < ac){
        fill_array(array, av[index]); 
        index += 1;
    }
    print_array(array);
}