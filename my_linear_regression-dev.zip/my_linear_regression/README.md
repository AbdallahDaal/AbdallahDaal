# Welcome to My Linear Regression
***

## Task
The problem is to implement and understand Linear Regression using both closed-form solutions and gradient descent optimization. The challenge involves:
- Implementing the linear hypothesis function.
- Defining and optimizing the Mean Squared Error (MSE) function.
- Implementing the Least Squares Regression model.
- Using Gradient Descent to minimize a function and visualize the results.

## Description
This project involves the following steps:
1. Implement Linear Hypothesis Function: Create a function to compute predictions based on feature weights.

2. Implement Mean Squared Error Function: Define the cost function for evaluating the performance of the linear model.

3. Add Bias Column: Modify the feature matrix to include a bias term.

4. Least Squares Regression: Implement a class to compute the optimal weights using the Normal Equation and make predictions.

5. Gradient Descent: Implement a class to perform gradient descent optimization and visualize the progression of the optimization.


## Installation
My project does not require any installations.

## Usage
1. Linear Hypothesis Function: Define the hypothesis function to make predictions.

2. Mean Squared Error: Implement and use the MSE function to evaluate model performance.

3. Bias Column: Add a bias column to the feature matrix for linear regression.

4. Least Squares Regression: Create an instance of LeastSquaresRegression, fit the model, and make predictions.

5. Gradient Descent: Use GradientDescentOptimizer to optimize a function, plot the function, and visualize the optimization process.
```
./my_linear_regression

```

### The Core Team


<span><i>Made at <a href='https://qwasar.io'>Qwasar SV -- Software Engineering School</a></i></span>
<span><img alt='Qwasar SV -- Software Engineering School's Logo' src='https://storage.googleapis.com/qwasar-public/qwasar-logo_50x50.png' width='20px' /></span>
