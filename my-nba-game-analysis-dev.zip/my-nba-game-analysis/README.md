# Welcome to My Nba Game Analysis
In Part 1, create a function analyse_nba_game(play_by_play_moves) which receives an array of play and will return a dictionary summary of the game.
In Part 2, Create a print_nba_game_stats(team_dict) function which will print a dictionary with name and players_data will print it with the format where each column is separated by a tabulation (' ').
## Task
Due to the bulkness of the code, I was mixing the variable names with the default dictionaries. The challenge was matching with regular expressions.
## Description
I consulted a friend that already did the project turned out I didn't use brackets on my RE code.

## Installation
My project does not require any installation.

## Usage
My project collected raw data on a basketball NBA game and prints it organised and more detailed.
```
./my_project my_nba_game_analysis.py
```

### The Core Team


<span><i>Made at <a href='https://qwasar.io'>Qwasar SV -- Software Engineering School</a></i></span>
<span><img alt='Qwasar SV -- Software Engineering School's Logo' src='https://storage.googleapis.com/qwasar-public/qwasar-logo_50x50.png' width='20px' /></span>
