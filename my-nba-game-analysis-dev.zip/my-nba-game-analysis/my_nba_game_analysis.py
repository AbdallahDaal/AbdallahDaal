import csv
import re
import pandas as pd

def loadfile(file_name):
    with open(file_name, newline='') as csvfile:
        reader = csv.reader(csvfile, delimiter='|')
        return list(reader) 

def analyse_nba_game(csvobj):
    game_dict = {"home_team": {"name": '', "players_data": {}}, 
                  "away_team": {"name": '', "players_data": {}}}
    
    for row in csvobj:
        # play_data = row.split('|')
        relevant_team = row[2]   
        home_team = row[4]
        away_team = row[3]
        description = row[7]

        tov_p = re.compile(r'Turnover by (\b[A-Z]\. [A-Za-z]+\b)')
        three_p = re.compile(r'(\b[A-Z]\. [A-Za-z]+\b) makes 3-pt jump shot from')
        two_p = re.compile(r'(\b[A-Z]\. [A-Za-z]+\b) makes 2-pt'  )
        
        tov_data = tov_p.search(description)
        three_data = three_p.search(description)
        two_data = two_p.search(description)
        
        if tov_data or three_data or two_data:
            if tov_data:
                player_name = tov_data.group(1)
                stat = "TOV"
            if three_data:
                player_name = three_data.group(1)
                stat = "3PT"
            if two_data:
                player_name = two_data.group(1)
                stat = "FG"

        team_key = "home_team" if relevant_team == home_team else "away_team"
        game_dict[team_key]["name"] = home_team if team_key == "home_team" else away_team

        if player_name not in game_dict[team_key]["players_data"]:
            game_dict[team_key]["players_data"][player_name] = {"TOV": 0, "3PT": 0, "FG": 0}
            
        game_dict[team_key]["players_data"][player_name][stat] += 1
            
    return game_dict

def print_nba_game_stats(team_dict, team_key):
    players_data = team_dict[team_key]["players_data"]
    rows = []
    for player_name, stats in players_data.items():
        row = {"Player": player_name, **stats}
        rows.append(row)
    df = pd.DataFrame(rows)
    df.set_index('Player', inplace=True)
    return df
  
y = analyse_nba_game(loadfile('pbpmini.txt'))
print(print_nba_game_stats(y, "away_team"))