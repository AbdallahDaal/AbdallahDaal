# Welcome to My Mobapp Studio
***

## Task
This is a group project and my partner and I were tasked to analyze the market for mobile apps on the Google Play Store. This involves understanding various metrics such as the size of the market, category distributions, app download ratios, and other valuable insights. The challenge is to efficiently process and analyze the data, and present our findings in a comprehensive and actionable format.

## Description
Solving this problem involved the following:
1. Loading the Dataset
2. Cleaning the Dataset
3. Performing Exploratory Data Analysis (EDA)
4. Visualizing Insights
5. Writing Reports

## Installation
Make sure to have the following python libraries installed before running our project:

1. pandas
2. numpy
3. matplotlib
4. seaborn

Install the above libraries using the 'pip install' function.

## Usage
Use the below steps as guide through our project:

1. Load the Dataset: Implement a function to load the dataset into a Pandas DataFrame.

2. Analyze and Clean Data: Implement functions to summarize, clean, and analyze the dataset.

3. Visualization: Use Matplotlib and Seaborn to create various plots such as histograms, pie charts, and bar diagrams.


```
./my_mobapp_studio - link_to_blog_post.txt
```

### The Core Team


<span><i>Made at <a href='https://qwasar.io'>Qwasar SV -- Software Engineering School</a></i></span>
<span><img alt='Qwasar SV -- Software Engineering School's Logo' src='https://storage.googleapis.com/qwasar-public/qwasar-logo_50x50.png' width='20px' /></span>
