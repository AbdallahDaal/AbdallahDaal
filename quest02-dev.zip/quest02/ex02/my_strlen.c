#include <stdio.h>

int my_strlen(char* param_1){

int num = 0;
while (*param_1 != '\0') {
    num++;
    param_1++;
}
return num;
}