# Welcome to Quest02
***

## Task
There wasn't any problem observed in my code.

## Description
How have you solved the problem?

## Installation
Doesn't require any installation.

## Usage
By running Gandalf.
```
./my_project argument1 argument2
```

### The Core Team


<span><i>Made at <a href='https://qwasar.io'>Qwasar SV -- Software Engineering School</a></i></span>
<span><img alt='Qwasar SV -- Software Engineering School's Logo' src='https://storage.googleapis.com/qwasar-public/qwasar-logo_50x50.png' width='20px' /></span>
