#include <stdio.h>
int my_sub(int param_1, int param_2){
    int subtraction = param_1 - param_2;
    return subtraction;
}