#include <stdio.h>

char* my_upcase(char* param_1){
    
    char *r = param_1;
    
    while (*param_1 != '\0'){
        if (*param_1 >= 'a' && *param_1 <= 'z'){
            
            *param_1 = *param_1 - ('a' - 'A');
        } 
        param_1++;
    }
    return r;
}