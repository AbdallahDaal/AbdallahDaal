#include <stdio.h>
int my_add(int param_1, int param_2){
    int addition = param_1 + param_2;
    return addition;
}
