#include <stdio.h>
void my_string_formatting(const char* param_1, const char* param_2, int param_3){
    printf("Hello, my name is %s %s, I'm %d.\n", param_1, param_2, param_3);

}