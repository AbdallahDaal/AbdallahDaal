#include <stdio.h>
int my_mult(int param_1, int param_2){
int multiplication = param_1 * param_2;
return multiplication;
}