# Welcome to My Vivino
***

## Task
The main problem we are addressing is the need to understand the market landscape for our wine offerings more comprehensively. 
Without a clear analysis of market size, potential opportunities, and competitive dynamics, we risk missing out on growth and innovation. 
The challenge lies in accurately identifying key trends and regions that can drive our business forward.

## Description
To tackle this issue, we conducted a thorough market size analysis. 
By examining various factors such as Prices, Potential sales(P_sales), NumberOfRatings(number of potential customers), Winery, Country...
We plotted charts from our dataset to visualize trends in the wine market
We intepreted the charts to draw insights and make conclusions 


## Installation
To set up the project, clone the repository and navigate to the project directory. 
You can install the necessary dependencies with the following command:
pip install seaborn
pip install pandas
pip install matplotlib

## Usage
The analysis involves collecting and processing market data to visualize trends and insights. 
We use code for data manipulation and visualization, creating reports and presentation slides to effectively communicate our findings. 
This analysis will inform the company to make strategic decisions.
```
./my_vivino.ipynb
```

### The Core Team
abdallah dal
gwazachok emmanuel

<span><i>Made at <a href='https://qwasar.io'>Qwasar SV -- Software Engineering School</a></i></span>
<span><img alt='Qwasar SV -- Software Engineering School's Logo' src='https://storage.googleapis.com/qwasar-public/qwasar-logo_50x50.png' width='20px' /></span>
