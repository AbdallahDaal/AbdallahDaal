import csv
import numpy as np 

class MySelectQuery:
    def __init__(self, string):
       
        self.csvdata = string.split('\n')
       
    def where(self, column, value):
        lstt = list()
        for row in self.csvdata[1:]:
            if value in row:
                lstt.append(row)
        return lstt

        

