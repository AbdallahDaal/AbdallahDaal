# Welcome to My Select Query
***

## Task
The contents of the file kept merging and not separating by classes. 

## Description
By using the append function to go through the contents of the file.

## Installation
My project does not require any installation.

## Usage
My project takes 2 arguments: column_name and value and returns an array of strings which matches the value.
```
./python my_select_query.py
```

### The Core Team


<span><i>Made at <a href='https://qwasar.io'>Qwasar SV -- Software Engineering School</a></i></span>
<span><img alt='Qwasar SV -- Software Engineering School's Logo' src='https://storage.googleapis.com/qwasar-public/qwasar-logo_50x50.png' width='20px' /></span>
