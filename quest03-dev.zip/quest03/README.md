# Welcome to Quest03
***

## Task
When the code gets bulky, it's easy to make errors and hard to spot them.

## Description
By googling and help of my colleagues.

## Installation
My project does not require any installation.

## Usage
By running it through gandalf to test it.
```
./my_project argument1 argument2
```

### The Core Team


<span><i>Made at <a href='https://qwasar.io'>Qwasar SV -- Software Engineering School</a></i></span>
<span><img alt='Qwasar SV -- Software Engineering School's Logo' src='https://storage.googleapis.com/qwasar-public/qwasar-logo_50x50.png' width='20px' /></span>
