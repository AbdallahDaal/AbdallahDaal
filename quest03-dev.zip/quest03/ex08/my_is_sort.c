#include <stdbool.h>
#ifndef STRUCT_INTEGER_ARRAY
#define STRUCT_INTEGER_ARRAY
typedef struct s_integer_array
{
    int size;
    int* array;
} integer_array;
#endif

bool my_is_sort(integer_array* param_1) {
    int* arr = param_1->array;
    int size = param_1->size;

    if (size <= 1) {
        return true; 
    }

    bool is_ascending = true;
    for (int i = 1; i < size; i++) {
        if (arr[i] < arr[i - 1]) {
            is_ascending = false;
            break;
        }
    }

    if (is_ascending) {
        return true; 
    }

    bool is_descending = true;
    for (int i = 1; i < size; i++) {
        if (arr[i] > arr[i - 1]) {
            is_descending = false;
            break;
        }
    }

    return is_descending;
}