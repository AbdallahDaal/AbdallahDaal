#ifndef STRUCT_INTEGER_ARRAY
#define STRUCT_INTEGER_ARRAY
typedef struct s_integer_array
{
    int size;
    int* array;
} integer_array;
#endif

#include <stdio.h>
#include <stdlib.h>

void my_first_struct(integer_array* param_1) {
    printf("%d\n", param_1->size); 
    if (param_1->size == 0 || param_1->array == NULL) {
        printf("0\n"); 
    } else {
        for (int i = 0; i < param_1->size; i++) {
            printf("%d\n", param_1->array[i]); 
        }
    }
}

void free_integer_array(integer_array* arr) {
    free(arr->array); 
}