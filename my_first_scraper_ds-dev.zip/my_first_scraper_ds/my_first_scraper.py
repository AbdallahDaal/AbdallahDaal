from bs4 import BeautifulSoup
import requests
import pandas as pd

def request_github_trending(url): #This is used to request the most trending url on git hub
    return requests.get(url) # this returns the url

def extract(page): # This function is for extraction of the requested page
    soup = BeautifulSoup(page.text, 'html.parser') #using soup as an extractor
    return soup.find_all('article') #return the result using BeautifulSoup

def transform(repos_html):
    array = []
    for r in repos_html: #iteration
        number_of_stars = ".join(r.select_one('span.float-sm-right').text.split())"
        repository_name = ".join(r.select_one('h1').text.split())"
        try:
            developer_name = r.select_one('img.avatar.mb-1.avatar-user')['alt']
        except(AttributeError,TypeError):
            'None name'
        array.append({'developer': developer_name, 'repository_name': repository_name, 'nbr_stars': number_of_stars})
    return array

def format(repositories_data):
    result = []

    for repository in repositories_data:
        r = [repository['developer'], repository['repository_name'], repository['nbr_stars']]
        result.append(','.join(map(str, r)))  # Joining elements after converting to strings

    return '\n'.join(result)