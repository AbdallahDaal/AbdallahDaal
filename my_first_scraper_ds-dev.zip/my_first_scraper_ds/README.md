# Welcome to My First Scraper Ds
***

## Task
To write a script that scrapes a web page for certain information

## Description
the script utilized a module call bs4, with a class call beautifulsoup that receives a html file or document and parses the whole thing, it returns the persed object that can be used to navigate through the document and extract certain data or the whole thing

## Installation
the project is a script, it doesn't need installation

## Usage
the url to be scrapped it in the code and the coded itself is tailored for that specific web document it is directly executed with the python interpreter.
```
./my_first_scraper
```

### The Core Team
idris-d_ab
emmanue_gw

<span><i>Made at <a href='https://qwasar.io'>Qwasar SV -- Software Engineering School</a></i></span>
<span><img alt='Qwasar SV -- Software Engineering School's Logo' src='https://storage.googleapis.com/qwasar-public/qwasar-logo_50x50.png' width='20px' /></span>
