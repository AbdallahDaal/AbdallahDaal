# Welcome to Visa For Lisa
***

## Task
TODO - What is the problem? And where is the challenge?
Galaxy Bank is looking to enhance its ability to convert deposit customers into personal loan customers while retaining them as depositors. 
The challenge is that not all clients offered loans accept them, despite a previous loan acceptance rate of over 9%. The bank's marketing department aims to improve targeting for their campaigns, but they need a more effective way to predict which deposit customers are most likely to accept loan offers. 
Without this insight, they risk wasting resources on ineffective marketing efforts.

## Description
TODO - How have you solved the problem?
To address this challenge, I developed a multi-variable linear regression model designed to analyze the bank’s customer data. 
This model identifies key factors influencing loan acceptance, allowing the marketing team to better target their campaigns. 
By focusing on customers who are most likely to accept loans
Galaxy Bank can optimize its marketing efforts and improve conversion rates, ultimately driving more business while maintaining strong relationships with existing depositors.
Also did some research on SMOTE (Synthetic Minority Oversampling Technique), found it to go perfectly and necessary for my code due to imbalance in my dataset by creating fake data level b
## Installation
TODO - How to install your project? npm install? make? make re?
For the code to work, some installations of libraries are required. How to install:
pip install scikit-learn
pip install imblearn
pip install seaborn


## Usage
TODO - How does it work?
```
./my_project argument1 argument2
```

### The Core Team


<span><i>Made at <a href='https://qwasar.io'>Qwasar SV -- Software Engineering School</a></i></span>
<span><img alt='Qwasar SV -- Software Engineering School's Logo' src='https://storage.googleapis.com/qwasar-public/qwasar-logo_50x50.png' width='20px' /></span>
