# Welcome to My Ds Babel
***

## Task
Problem: Convert data between SQL and CSV formats. Specifically:

SQL to CSV: Extract data from an SQLite table and convert it to a CSV string.
CSV to SQL: Read a CSV formatted string, create an SQLite table, and insert the CSV data into this table.
Challenge: Properly querying, formatting, and inserting data while managing SQLite and CSV formats.

## Description
sql_to_csv(database, table_name): Connect to an SQLite database, retrieve data from a specified table, and format it as a CSV string including headers.

csv_to_sql(csv_content, database, table_name): Read CSV data, create a new table in an SQLite database with columns based on CSV headers, and insert the CSV rows into this table.

## Installation
Doesn't require any installations

## Usage
To convert SQL to CSV:

Use sql_to_csv with the database filename and table name to get a CSV string of the table's data.
To convert CSV to SQL:

Use csv_to_sql with a CSV string, the database filename, and the table name to create the table and insert the CSV data into it.
```
./my_ds_babel.py - list_volcano.db - list_fault_lines.csv
```

### The Core Team


<span><i>Made at <a href='https://qwasar.io'>Qwasar SV -- Software Engineering School</a></i></span>
<span><img alt='Qwasar SV -- Software Engineering School's Logo' src='https://storage.googleapis.com/qwasar-public/qwasar-logo_50x50.png' width='20px' /></span>
