import sqlite3
import csv
from io import StringIO



def sql_to_csv(dataBase, table_Name):
    # Connect to SQLite database
    sqcon = sqlite3.connect(dataBase)
    cursorr = sqcon.cursor()


    # Fetch all rows from the table
    cursorr.execute(f"SELECT * FROM {table_Name};")
    rows = cursorr.fetchall()


    # Get column names
    cursorr.execute(f"PRAGMA table_info({table_Name});")
    coll = [col[1] for col in cursorr.fetchall()]


    # Prepare CSV content
    csv_out = StringIO()
    csv_writa = csv.writer(csv_out, lineterminator='\n')  # Ensure consistent line endings


    # Write header
    csv_writa.writerow(coll)


    # Write rows
    csv_writa.writerows(rows)


    # Close database connection
    sqcon.close()


    # Return CSV formatted string
    return csv_out.getvalue().strip()




# Function to convert CSV content to SQL and insert into a table


def csv_to_sql(csv_content, dataBase, table_Name):
    # Connect to SQLite database
    sqcon = sqlite3.connect(dataBase)
    cursorr = sqcon.cursor()
   
    # Read CSV content from StringIO object
    reada = csv.reader(csv_content)
    heada = next(reada)


    # Sanitize column names
    sheada = [f'"{coll}"' for coll in heada]


    # Create table
    cursorr.execute(f'''
        CREATE TABLE IF NOT EXISTS {table_Name} (
            {', '.join([f"{coll} TEXT" for coll in sheada])}
        )
    ''')


    # Prepare to insert query
    query = f'INSERT INTO {table_Name} ({",".join(sheada)}) VALUES ({",".join("?" * len(heada))})'


    # Insert data into the table
    for row in reada:
        cursorr.execute(query, row)


    # Commit and close connection
    sqcon.commit()
    sqcon.close()