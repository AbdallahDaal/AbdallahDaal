#include<stdio.h>
#include<string.h>
#include<stdlib.h>
char* my_strdup(char* param_1){
      if (param_1 == NULL) {
        return NULL;
    }

    size_t len = strlen(param_1) + 1; 

    char* new_str = (char*)malloc(len * sizeof(char));
    if (new_str == NULL) {
      return NULL;
    }

    strcpy(new_str, param_1);

    return new_str;
}

