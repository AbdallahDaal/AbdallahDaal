#include <stdlib.h>
#include <stdio.h>

int* my_range(int min, int max){
     if(min >= max){
         return NULL;
     }
     int range = max - min;
        int* arr = (int*)malloc(range * sizeof(int));
    if (arr == NULL) {
        printf("Memory allocation failed\n");
        exit(1);
    }

    // Fill the array with values from min to max
    for (int i = 0; i < range; i++) {
        arr[i] = min + i;
    }

    return arr;
   
}