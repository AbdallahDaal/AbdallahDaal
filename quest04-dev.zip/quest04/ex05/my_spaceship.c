#include <stdio.h>
#include <string.h>
#include <stdlib.h>
typedef struct {
int x;
int y;
char direction[6]; 
} Position;
char* my_spaceship(char* operation) {
int x = 0, y = 0;
char D[6] = "up";
char* space[4] = {"up", "right", "down", "left"};
for (int i = 0; i < strlen(operation); i++) {
char path = operation[i];
if (path == 'R') {
int index = -1;
for (int j = 0; j < 4; j++) {
if (strcmp(space[j], D) == 0) {
index = j;
break;
}
}
index = (index + 1) % 4;
strcpy(D, space[index]);
} else if (path == 'L') {
int index = -1;
for (int j = 0; j < 4; j++) {
if (strcmp(space[j], D) == 0) {
index = j;
break;
}
}
index = (index - 1 + 4) % 4;
strcpy(D, space[index]);
} else if (path == 'A') {
if (strcmp(D, "up") == 0) y--;
else if (strcmp(D, "down") == 0) y++;
else if (strcmp(D, "left") == 0) x--;
else if (strcmp(D, "right") == 0) x++;
}
}
char* result = (char*)malloc(100 * sizeof(char)); // Assuming a maximum length for the output string
snprintf(result, 100, "{x: %d, y: %d, direction: '%s'}", x, y, D); // Remove '\n' from the format string
return result;
}