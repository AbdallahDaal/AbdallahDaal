#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#ifndef STRUCT_STRING_ARRAY
#define STRUCT_STRING_ARRAY
typedef struct s_string_array
{
    int size;
    char** array;
} string_array;
#endif

char* my_join(string_array* strings, char* separator) {
    if (strings == NULL || strings->array == NULL || strings->size <= 0) {
        return NULL;
    }
    size_t total_length = 0;
    for (int i = 0; i < strings->size; i++) {
        total_length += strlen(strings->array[i]);
    }
    total_length += (strings->size - 1) * strlen(separator) + 1; 

    char* combined_string = (char*)malloc(total_length * sizeof(char));
    if (combined_string == NULL) {
        return NULL;
    }
    strcpy(combined_string, strings->array[0]);

    for (int i = 1; i < strings->size; i++) {
        strcat(combined_string, separator);
        strcat(combined_string, strings->array[i]);
    }

    return combined_string;
}
