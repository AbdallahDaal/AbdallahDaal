#include <stdlib.h>
#include <strings.h>
#include <unistd.h>

#ifndef STRUCT_STRING_ARRAY
#define STRUCT_STRING_ARRAY
typedef struct s_string_array
{
    int size;
    char** array;
} string_array;
#endif

void my_putstr(const char *str) {
    for (int i = 0; str[i] != '\0'; i++) {
        // putchar(str[i]);
        write(1, &str[i], 1);
    }
}

void my_print_words_array(string_array* param_1) {
    if (param_1 == NULL || param_1->array == NULL) {
        return;
    }

    
    for (int i = 0; i < param_1->size; i++) {
          my_putstr(param_1->array[i]);
        my_putstr("\n");
    }
}