# Welcome to Ds Quest04
***

## Task
No problems encountered in this quest, and no challenges.

## Description
Research had to be done on Sci-kitlearn.com and everything came with ease.

## Installation
My project does not require any installation.

## Usage
By the use of the sklearn.metrics library.
```
./my_model_evaluation_journey_r2_score.py my_model_evaluation_journey_mean_squared_error.py my_model_evaluation_journey_mean_absolute_error.py my_model_evaluation_journey_confusion_matrix.py my_model_evaluation_journey_accuracy_score.py my_model_evaluation_journey_recall_score.py my_model_evaluation_journey_f_one.py
```

### The Core Team


<span><i>Made at <a href='https://qwasar.io'>Qwasar SV -- Software Engineering School</a></i></span>
<span><img alt='Qwasar SV -- Software Engineering School's Logo' src='https://storage.googleapis.com/qwasar-public/qwasar-logo_50x50.png' width='20px' /></span>
