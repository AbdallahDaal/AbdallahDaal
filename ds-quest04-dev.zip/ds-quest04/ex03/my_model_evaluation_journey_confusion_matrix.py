import numpy as np
from sklearn.metrics import confusion_matrix
def my_model_evaluation_journey_confusion_matrix(p1, p2):
    return confusion_matrix(p1, p2)