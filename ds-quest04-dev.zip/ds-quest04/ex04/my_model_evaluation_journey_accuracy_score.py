import numpy as np
from sklearn.metrics import accuracy_score
def my_model_evaluation_journey_accuracy_score(p1, p2):
    return accuracy_score(p1, p2)