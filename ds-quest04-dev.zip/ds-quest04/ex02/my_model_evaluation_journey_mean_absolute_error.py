import pandas as pd  
from sklearn.metrics import mean_absolute_error
def my_model_evaluation_journey_mean_absolute_error(p1, p2):
    df = pd.read_csv(p1).drop(columns=['robot_model_name'])
    df2 = pd.read_csv(p2).drop(columns=['robot_model_name']).head(16)
    return mean_absolute_error(df, df2)
