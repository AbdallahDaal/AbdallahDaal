import numpy as np
from sklearn.metrics import f1_score

def my_model_evaluation_journey_f_one(p1, p2):
    return f1_score(p1, p2, average=None)
