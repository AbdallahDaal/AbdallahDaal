import pandas as pd  
from sklearn.metrics import r2_score

def my_model_evaluation_journey_r2_score(param_1, param_2):
    df = pd.read_csv(param_1).drop(columns=['robot_model_name'])
    df2 = pd.read_csv(param_2).drop(columns=['robot_model_name']).head(16)

    return r2_score(df, df2)