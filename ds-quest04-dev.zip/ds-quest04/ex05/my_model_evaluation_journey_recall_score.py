from sklearn.metrics import recall_score
import numpy as np
def my_model_evaluation_journey_recall_score(p1, p2):
    return recall_score(p1, p2, average=None)