# Welcome to Ds Quest00
***

## Task
There wasn't any challenge there, creating the notebook with Jupyter was easy.

## Description
There was not any problem encountered within the project.

## Installation
My project doesn't require any installations

## Usage
By starting the Jupyter browser and opening the already created folders and some files within them.
```
./	my_jupyter_journey_first_notebook.ipynb
```

### The Core Team


<span><i>Made at <a href='https://qwasar.io'>Qwasar SV -- Software Engineering School</a></i></span>
<span><img alt='Qwasar SV -- Software Engineering School's Logo' src='https://storage.googleapis.com/qwasar-public/qwasar-logo_50x50.png' width='20px' /></span>
