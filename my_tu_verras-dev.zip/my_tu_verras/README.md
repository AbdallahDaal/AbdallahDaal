# Welcome to My Tu Verras
***

## Task
Understand a given dataset
Build a linear regression prediction model that fits and predict based on that dataset

## Description
procedures include, loading the dataset and summarizing the dataset
used correlations to understand the realtionships between the columns or features
plotted scatter matrix graphs
fitted a linear reg model and predicted

## Installation
no Installation required, analysis are made off the notebook
## Usage
the model can be used to predict a feature based on other features
```
./my_tu_verras.ipynb
```

### The Core Team


<span><i>Made at <a href='https://qwasar.io'>Qwasar SV -- Software Engineering School</a></i></span>
<span><img alt='Qwasar SV -- Software Engineering School's Logo' src='https://storage.googleapis.com/qwasar-public/qwasar-logo_50x50.png' width='20px' /></span>
