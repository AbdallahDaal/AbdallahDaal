# Welcome to My Printf
***

## Task
The challenge was to avoid using unauthorized functions which would have made the code easier.

## Description
I carefully used the hints provided for the challenge. One of them were to avoid memory leaks.

## Installation
My project doesn't require any installations.

## Usage
It replaces the use of a normal printf() funtion in C language.
```
./my_printf(*str, ...)
```

### The Core Team


<span><i>Made at <a href='https://qwasar.io'>Qwasar SV -- Software Engineering School</a></i></span>
<span><img alt='Qwasar SV -- Software Engineering School's Logo' src='https://storage.googleapis.com/qwasar-public/qwasar-logo_50x50.png' width='20px' /></span>
