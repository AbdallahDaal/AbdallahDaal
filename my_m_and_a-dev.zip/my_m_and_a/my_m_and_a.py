import pandas as pd
import sqlite3
import csv
from io import StringIO
from my_ds_babel import csv_to_sql


def clean_table1():
    url_table1 = "https://storage.googleapis.com/qwasar-public/only_wood_customer_us_1.csv"
    df_table1 = pd.read_csv(url_table1)
    # Drop missing values
    cleaned_df = df_table1.dropna().copy()
    # Replace gender values
    cleaned_df.loc[:, "Gender"] = cleaned_df["Gender"].replace({"0": "Female", "1": "Male"}).astype(str)
    cleaned_df.loc[:, "Gender"] = cleaned_df["Gender"].replace({"F": "Female", "M": "Male"}).astype(str)
    # Clean the FirstName column
    cleaned_df.loc[:, "FirstName"] = cleaned_df["FirstName"].str.strip('"\\').str.title()
    # Clean the LastName column
    cleaned_df.loc[:, "LastName"] = cleaned_df["LastName"].str.strip('"\\').str.title()
    # Convert email to lowercase
    cleaned_df.loc[:, "Email"] = cleaned_df["Email"].str.lower()
    # Capitalize city names
    cleaned_df.loc[:, "City"] = cleaned_df["City"].str.title()
    cleaned_df.loc[:, "UserName"] = cleaned_df["UserName"].str.title()
    cleaned_df.loc[:, "Country"] = "USA"
    cleaned_df.loc[:, "Age"] = cleaned_df["Age"].astype(str)
    
    return cleaned_df


def clean_table2():
    url_table2 = "https://storage.googleapis.com/qwasar-public/only_wood_customer_us_2.csv"
    table_columns = ["Age", "City", "Gender", "Name", "Email"]
    # Read CSV file
    df_table2 = pd.read_csv(url_table2, names=table_columns, sep=';')
    # Drop missing values
    cleaned_df = df_table2.dropna().copy()
    cleaned_df["Age"] = cleaned_df["Age"].str.extract('(\d+)')  # Extract numeric part
    # Ensure 'Gender' column is treated as a string for replacement
    cleaned_df["Gender"] = cleaned_df["Gender"].astype(str)
    
    # Replace all gender values
    cleaned_df["Gender"] = cleaned_df["Gender"].replace({"0": "Female", "1": "Male"}).astype(str)
    cleaned_df["Gender"] = cleaned_df["Gender"].replace({"F": "Female", "M": "Male"}).astype(str)
    
    cleaned_df.loc[:, "Email"] = cleaned_df["Email"].str.lower()
    # Split and clean the Name column
    cleaned_df[['FirstName', 'LastName']] = cleaned_df['Name'].str.split(expand=True, n=1)
    cleaned_df["FirstName"] = cleaned_df["FirstName"].str.strip('"\\').str.title()
    cleaned_df["LastName"] = cleaned_df["LastName"].str.strip('"\\').str.title()
    # Capitalize city names
    cleaned_df.loc[:, "City"] = cleaned_df["City"].str.title()
    # Drop the Name column
    cleaned_df.drop(columns=['Name'], inplace=True)
    cleaned_df = cleaned_df[['Gender', 'FirstName', 'LastName', 'Email', 'Age', 'City']]
    
    return cleaned_df


def clean_table3():
    url_table3 = "https://storage.googleapis.com/qwasar-public/only_wood_customer_us_3.csv"
    table_columns = ['Gender', 'Name', 'Email', 'Age', 'City', 'Country']
    # Read CSV file
    df_table3 = pd.read_csv(url_table3, sep='\t|,', engine='python')
    # Assign custom column names
    df_table3.columns = table_columns
    # Drop missing values
    cleaned_df = df_table3.dropna().copy()
    cleaned_df["Age"] = cleaned_df["Age"].str.extract('(\d+)')  # Extract numeric part
    cleaned_df.loc[:, "City"] = cleaned_df["City"].str.replace("string_", "").str.title()
    # Clean and split the Name column
    cleaned_df.loc[:, "Name"] = cleaned_df["Name"].str.replace("string_", "")
    cleaned_df[['FirstName', 'LastName']] = cleaned_df['Name'].str.split(expand=True, n=1)
    cleaned_df["FirstName"] = cleaned_df["FirstName"].str.strip('"\\').str.title()
    cleaned_df["LastName"] = cleaned_df["LastName"].str.strip('"\\').str.title()
    # Assign the values in column Country to USA
    cleaned_df.loc[:, "Country"] = "USA"
    # Clean and convert the emails to lowercase
    cleaned_df.loc[:, "Email"] = cleaned_df["Email"].str.replace("string_", "").str.lower()
    # Map gender values to their correct representation
    gender_mapping = {
        'string_Male': 'Male',
        'string_Female': 'Female',
        'boolean_0': 'Female',
        'boolean_1': 'Male',
        'character_M': 'Male',
        'character_F': 'Female',
    }
    cleaned_df["Gender"] = cleaned_df["Gender"].map(gender_mapping).astype(str)
    # Drop the Name column
    cleaned_df.drop(columns=['Name'], inplace=True)
    # Rearrange the column headers
    cleaned_df = cleaned_df[['Gender', 'FirstName', 'LastName', 'Email', 'Age', 'City']]
    
    return cleaned_df


def my_m_and_a(table1, table2, table3):
    # Clean the tables
    df1 = clean_table1()
    df2 = clean_table2()
    df3 = clean_table3()
    
    # Concatenate the dataframes
    merged_df = pd.concat([df1, df2, df3], ignore_index=True)
    
    return merged_df

def main():
    # Clean the tables
    df1 = clean_table1()
    df2 = clean_table2()
    df3 = clean_table3()
    
    merged_data = my_m_and_a(df1, df2, df3)

    if not merged_data.empty:
        merged_data.to_csv('merged_data.csv', index=False)
        csv_to_sql('merged_data.csv', 'plastic_free_boutique.sql', 'customers')
    else:
        print("Error in processing data. No output generated.")

if __name__ == '__main__':
    main()
