# Welcome to My M And A
***

## Task
Integrating customer information from Only Wood Box, a recently acquired business, into our current client database presents a difficulty. 
The only Wood Box firm has three tables where its customers' information is stored and very little digital infrastructure.

## Description
three different CSV files containing the customer data were loaded into Pandas DataFrames.
we created a single, cohesive DataFrame by combining various DataFrames.
we modified and cleaned the data to fit the structure of our current database.
we added the combined data to the pre-existing customer database that is built on SQL.
## Installation
Runtime for this project does not require any extra installation. 
Just make sure that Python and the pandas libraries standard packages for working with data and databases in Python are installed on your machine.
## Usage

```
Transfer the Only Wood Box client data (table1.csv, table2.csv, and table3.csv) into the project directory using the CSV files.
Start the script so that the data is merged into the current database.

```

### The Core Team

Akan Emmanuel and Abdallah Idris Dal

<span><i>Made at <a href='https://qwasar.io'>Qwasar SV -- Software Engineering School</a></i></span>
<span><img alt='Qwasar SV -- Software Engineering School's Logo' src='https://storage.googleapis.com/qwasar-public/qwasar-logo_50x50.png' width='20px' /></span>
