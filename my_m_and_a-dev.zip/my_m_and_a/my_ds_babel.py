import sqlite3
import csv
from io import StringIO




def csv_to_sql(csv_content, dataBase, table_Name):
    # Connect to SQLite database
    conn = sqlite3.connect(dataBase)
    cursor = conn.cursor()


    reader = csv.reader(csv_content)
    header = next(reader)

    # Sanitize column names
    sanitized_header = [f'"{column}"' for column in header]

    # Create table
    cursor.execute(f'''
        CREATE TABLE IF NOT EXISTS {table_Name} (
            {', '.join([f"{column} TEXT" for column in sanitized_header])}
        )
    ''')


    # Prepare to insert query
    query = f'INSERT INTO {table_Name} ({",".join(sanitized_header)}) VALUES ({",".join("?" * len(header))})'
    # Insert data into the table
    for row in reader:
        cursor.execute(query, row)


    # Commit and close connection
    conn.commit()
    conn.close()