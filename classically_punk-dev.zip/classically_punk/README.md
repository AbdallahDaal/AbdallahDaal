# Welcome to Classically Punk
***

## Task
The goal of this project was to develop a model that can classify music tracks into 10 different genres by extracting key audio features and training a predictive model.

## Description
To achieve this, I used the following Python libraries and tools:
Librosa for extracting Mel spectrograms and other audio features from the tracks.
NumPy for numerical operations on the extracted data.
TensorFlow for building and training the Convolutional Neural Network (CNN) for music genre classification.
Matplotlib for visualizing the features and model performance.
Sci-Kit Learn for splitting the dataset into training, validation, and test sets.
Confusion Matrix for evaluating the classification performance.

## Installation
To run this project, you'll need to install the following Python libraries:
pip install librosa tensorflow, numpy, scikit-learn, and matplotlib

## Usage
This project was developed and tested in Google Colab. Simply upload the dataset and run the provided notebook to train and evaluate the model.
```
./my_project clasically_punk
```

### The Core Team
Abdallah Dal

<span><i>Made at <a href='https://qwasar.io'>Qwasar SV -- Software Engineering School</a></i></span>
<span><img alt='Qwasar SV -- Software Engineering School's Logo' src='https://storage.googleapis.com/qwasar-public/qwasar-logo_50x50.png' width='20px' /></span>
