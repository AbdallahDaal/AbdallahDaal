# Welcome to Ds Quest01
***

## Task
There isn't any problem encountered during coding. Yes I have wrote all of it down.

## Description
I followed the instructions and the material provided to aid me which is a NumPy documentation.

## Installation
The project does not require any installation.

## Usage
It works when the provided parameters are filled up with the given problems.
```
./my_numpy_journey_one_d_array.py
```

### The Core Team


<span><i>Made at <a href='https://qwasar.io'>Qwasar SV -- Software Engineering School</a></i></span>
<span><img alt='Qwasar SV -- Software Engineering School's Logo' src='https://storage.googleapis.com/qwasar-public/qwasar-logo_50x50.png' width='20px' /></span>
