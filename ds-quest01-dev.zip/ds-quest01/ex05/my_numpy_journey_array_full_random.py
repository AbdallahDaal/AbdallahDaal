import numpy as np
def my_numpy_journey_array_full_random(param_1, param_2):
    return np.random.randint(10, size=(param_1, param_2))