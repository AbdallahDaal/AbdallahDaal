import numpy
def my_numpy_journey_one_d_array(param_1):
    

    return numpy.array([param_1])