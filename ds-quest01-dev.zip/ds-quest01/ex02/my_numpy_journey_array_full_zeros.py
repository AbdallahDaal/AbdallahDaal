import numpy
def my_numpy_journey_array_full_zeros(param_1):
    return numpy.zeros(param_1)