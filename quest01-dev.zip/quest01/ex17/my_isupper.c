char my_isupper(char upcase){
    return (upcase >= 'A' && upcase <= 'Z') ? 1 : 0;
}