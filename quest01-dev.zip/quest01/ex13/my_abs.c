#include <stdio.h>

int m_abs(int num);

// int main() {
//     int num = -10;
    
//     int abs_num = my_abs(num);
//     printf("The absolute value of %d is: %d\n", num, abs_num);
    
//     return 0;
// }
int my_abs(int num) {
    return (num < 0) ? -num : num;
}
