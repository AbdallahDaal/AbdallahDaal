#include <stdio.h>
#include <unistd.h>

void _putchar(char c){

    write(1,&c,1);
}

void my_print_alphabet() {
    char ch;
    for(ch = 'a'; ch <= 'z'; ++ch) {
        _putchar(ch);
    }
    _putchar('\n');
}