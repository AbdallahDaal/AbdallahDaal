int my_isdigit(int digit ) {
    return (digit >= '0' && digit <= '9') ? 1 : 0;
}