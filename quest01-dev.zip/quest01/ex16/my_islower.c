char my_islower(char lowcase){
    return (lowcase >= 'a' && lowcase <= 'z') ? 1 : 0;
}