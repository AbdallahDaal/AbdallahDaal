#include <stdio.h>
#include <unistd.h>

void _putchar(char c){

    write(1,&c,1);
}

void my_print_reverse_alphabet() {
    char ch;
    for(ch = 'z'; ch >= 'a'; --ch) {
        _putchar(ch);
    }
    _putchar('\n');
}