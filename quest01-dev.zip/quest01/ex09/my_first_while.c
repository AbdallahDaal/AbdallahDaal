#include <stdio.h>

int main() {
  int index = 0;

  while (index <= 99) {
    printf("I want to code\n");
    index++; 
  }
  return 0;
}
