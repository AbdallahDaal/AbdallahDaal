#include <stdio.h>

void detonation_in_(int seconds_left);

int main() {
    int timer = 10;

    while (timer > 0) {
        detonation_in_(timer); 
        timer--;
    }
    return 0;
}

void detonation_in_(int seconds_left) {
    printf("detonation in... %d seconds.\n", seconds_left);
}
