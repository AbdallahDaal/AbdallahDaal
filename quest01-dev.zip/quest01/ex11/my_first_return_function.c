#include <stdio.h>

int my_get_seven();

int main() {
    
    int result = my_get_seven();
    
    printf("%d\n", result);
    return 0;
}
int my_get_seven() {
    
    return 7;
}
