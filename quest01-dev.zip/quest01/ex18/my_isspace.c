int my_isspace(int space){
    return (space == ' ') ? 1 : 0;
}