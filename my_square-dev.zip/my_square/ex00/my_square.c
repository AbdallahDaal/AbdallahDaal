#include <stdio.h>
#include <stdlib.h> 


void print_horizontal(int width) {
    printf("o");
    for (int i = 0; i < width - 2; i++) {
        printf("-");
    }
    printf("o\n");
}

void print_vertical(int width) {
    printf("|");
    for (int i = 0; i < width - 2; i++) {
        printf(" ");
    }
    printf("|\n");
}

void my_square(int width, int height) {
    if (width < 2 || height < 2) {
        printf("");
        return;
    }

    print_horizontal(width);

    for (int i = 0; i < height - 2; i++) {
        print_vertical(width);
    }

    print_horizontal(width);
    
   
    
}

int main(int argc, char *argv[]) {
    
   if (argc == 2){
       return 0;
   }
   if (argc == 1) {
       return 0;
   }

    int width = atoi(argv[1]);
    int height = atoi(argv[2]);
    width = height;

    my_square(width, height);

    return 0;
}
