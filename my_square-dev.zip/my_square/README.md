# Welcome to My Square
***

## Task
My outputs weren't tallying with Gandalf's expected output, so I took a different approach. 

## Description
By taking the simpler solution with the help of a colleague and wrote specific codes to meet the expected output.

## Installation
My project doesn't require any installation. It works only when prompted.

## Usage
The project outputs a perfect square by inputting the same size os width and height on the frontend.
```
./my_square [arg1] [arg2]
```

### The Core Team


<span><i>Made at <a href='https://qwasar.io'>Qwasar SV -- Software Engineering School</a></i></span>
<span><img alt='Qwasar SV -- Software Engineering School's Logo' src='https://storage.googleapis.com/qwasar-public/qwasar-logo_50x50.png' width='20px' /></span>
