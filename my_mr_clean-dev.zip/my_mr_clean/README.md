# Welcome to My Mr Clean
***

## Task
There wasn't any problem encountered. The challenge was how bulk the code was, it was easy to get lost. 

## Description
I have solved the problem by working on the project and providing solutions to the questions asked.

## Installation
My project does not require any installation.

## Usage
It displays the most relevant words on a search engine.
```
./my_mr_clean.ipynb
```

### The Core Team


<span><i>Made at <a href='https://qwasar.io'>Qwasar SV -- Software Engineering School</a></i></span>
<span><img alt='Qwasar SV -- Software Engineering School's Logo' src='https://storage.googleapis.com/qwasar-public/qwasar-logo_50x50.png' width='20px' /></span>
