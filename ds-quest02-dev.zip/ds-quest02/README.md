# Welcome to Ds Quest02
Exploring the Pandas library.

## Task
I had no problems nor faced much challenges working on Pandas library.

## Description
I worked on the exercises provided and solved the problems by writing on the codes.

## Installation
My project does not require any installation.

## Usage
The use of Pandas and Numpy libraries.
```
./my_project my_pandas_journey_load_data.py
```

### The Core Team


<span><i>Made at <a href='https://qwasar.io'>Qwasar SV -- Software Engineering School</a></i></span>
<span><img alt='Qwasar SV -- Software Engineering School's Logo' src='https://storage.googleapis.com/qwasar-public/qwasar-logo_50x50.png' width='20px' /></span>
