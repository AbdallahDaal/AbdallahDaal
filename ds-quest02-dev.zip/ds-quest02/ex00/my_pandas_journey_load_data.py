import pandas as pd
import csv

def my_pandas_journey_load_data(param_1):
    return pd.read_csv(param_1)