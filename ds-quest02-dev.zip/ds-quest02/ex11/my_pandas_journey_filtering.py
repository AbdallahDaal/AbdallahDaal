import pandas as pd 
import numpy as np
def my_pandas_journey_filtering(param_1):
    filtered_content = param_1.loc[param_1['Index'] == 'A']
    return filtered_content